/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Computabilidad y Algoritmia
 *
 * @author Daniel Perez Lozano
 * @email alu0101339542@ull.edu.es
 * @date 21 Nov 2020
 * @brief Given a NFA from a file and a bounch of strings from another file the program should check if
 *  the given strings are accepted by the NFA and store the result in a 3rd file
 * @see http://www.cplusplus.com/doc/tutorial/program_structure/
 * @see http://cpp.sh/2dd
 * @compile  g++ -std=c++14 -g -Wall -o nfa_simulation nfa_simulation.cc main_nfa_simulation.cc
*/

#include "nfa_simulation.h"

int CheckInput(int argc, char *argv[]){
  ifstream input_file;
  ifstream nfa_data;
  ofstream output_file;
  nfa_data.open(argv[1]);
  input_file.open(argv[2]);

  if(argc != 4) {
    cout << "Syntax error: " << argv[0] << " was expecting the name of the nfa the strings file and the output file." << endl;
    cout << "--help for more information " << endl;
    return -1;
  } 
  if(nfa_data.fail()) {
    cout << "Error opening nfa file" << argv[1] << endl;
    //cerr << "Error: " << strerror(errno);
    return -1;
  }
  if(nfa_data.peek() == std::ifstream::traits_type::eof()) {
    cout<< "The nfa file is empty" << endl;
    return -1;
  }
  if(input_file.fail()) {
    cout << "Error opening input file" << argv[2] << endl;
    //cerr << "Error: " << strerror(errno);
    return -1;
  }
  if(input_file.peek() == std::ifstream::traits_type::eof()) {
    cout<< "The input file is empty" << endl;
    return -1;
  }
  output_file.open(argv[3]);
  if(output_file.fail()){
    cout << "Error opening output file" << endl;
    return -1;
  }
  if(argc == 2 && string(argv[1]) == "--help") {
    cout << "The program expects three parameters $> ./nfa_simulation input.nfa input.txt output.txt " << endl;
    cout << "nfa_simulation.data indicates the filename where it will take the nfa form" << endl;
    cout << "input.txt indicates the filename where it will take the strings form" << endl;
    cout << "output.txt is the filename where the result will get stored " << endl;
    return -1;
  }
  nfa_data.close();
  input_file.close();
  output_file.close();
  return 0;
}

Nfa::Nfa(string filename){
  ifstream nfa_data;
  symbolcount = 1;
  alphabet.insert(pair<char,int>('~',0));
  nfa_data.open(filename);
  ReadNumberStates(nfa_data);
  for(unsigned int i = 0; i < nstates; i++)
    delta[i].resize(symbolcount);
  ReadInitState(nfa_data);
  for(unsigned int i = 0; i < nstates; i++){
    ReadTransition(nfa_data);
  }
  nfa_data.close();
}
Nfa::~Nfa(){

}
ifstream& Nfa::ReadNumberStates(ifstream &input) {
  string n_state;
  //string foo;
  input >> n_state;
  /*input >> foo;
  if(foo.erase().length() != 0){ //<< removes new line from string*/
    /*cout << "An error has been found while reading the NFA file: number of states"<< endl;
    exit(EXIT_FAILURE); 
  }*/
  nstates = stoi(n_state);
  delta.resize(nstates);
  return input;
}
ifstream& Nfa::ReadInitState(ifstream &input) {
  string init_state;
  //string foo;
  input >> init_state;
  /*input >> foo;
  if(foo.erase().length() != 0){ //<< removes new line from string*/
    /*cout << "An error has been found while reading the NFA file: number of initial state"<< endl;
    exit(EXIT_FAILURE);
  }*/
  initial_state = stoi(init_state);
  return input;
}

ifstream& Nfa::ReadTransition(ifstream &input) {
  string state, accept, ntrans, symbol, destin_state;
  input >> state >> accept >> ntrans;
  if(stoi(accept) == 1) {
    accepted_states.insert(stoi(state));
  }
  for(int i = 0; i < stoi(ntrans); i++) {
    input >> symbol >> destin_state;
    InsertInAlphabet(symbol[0]);
    delta[stoi(state)][alphabet[symbol[0]]].insert(stoi(destin_state));
  }

  return input;
}

bool Nfa::InsertInAlphabet(unsigned char symbol){
  std::map<unsigned char, unsigned int>::iterator it;
  if(symbol != '~') {
    it = alphabet.find(symbol);
    if(it == alphabet.end()) {
      alphabet.insert(pair<unsigned char, unsigned int>(symbol, symbolcount));
      symbolcount++;
      for(unsigned int i = 0; i < nstates; i++)
        delta[i].resize(symbolcount);

      return false; /*<< It was not in the alphabet already */
    }
  }
  return true;
}

void Nfa::EpsClausure(set<int> current, set<int>& epsilonstates){
  int pstate;
  set<int> aux;
  //iterator<set<int>> it;
  stack<int> stk;
  for(auto it = current.begin(); it != current.end(); it ++) {
    stk.push(*it);
  }
  epsilonstates = current;
  while(!stk.empty()){
    pstate = stk.top();
    stk.pop();
    aux = delta[pstate][0];
    for(auto it = aux.begin(); it != aux.end(); it ++){
      if(epsilonstates.find(*it) == epsilonstates.end()){
        epsilonstates.insert(*it);
        stk.push(*it);
      } 
    }
  }
}

void Nfa::SymbolTransition(unsigned char symbol, set<int> current, set<int>& next){
  std::set<int> tmp;
  for(auto it = current.begin(); it != current.end(); it ++) {
    if(!delta[*it][alphabet[symbol]].empty()){
      std::set_union(delta[*it][alphabet[symbol]].begin(), delta[*it][alphabet[symbol]].end(), next.begin(), next.end(), inserter(tmp, tmp.begin()));
      next=tmp;
    }
  }
}

bool Nfa::Nfa_Simulate(string input_string){
  set<int> current, epsilon_curr, next, endset;
  current.insert(initial_state);
  EpsClausure(current, epsilon_curr);
  for(long unsigned int i=0; i < input_string.size(); i++){
    //check if symbol in alphabet
    SymbolTransition(input_string[i], epsilon_curr, next);
    epsilon_curr.clear();
    EpsClausure(next, epsilon_curr);
    next.clear();
  }
  set_intersection(epsilon_curr.begin(), epsilon_curr.end(), accepted_states.begin(), accepted_states.end(), inserter(endset, endset.begin()));
  if(!endset.empty())
    return true;
  else
    return false;
}


std::ostream &operator <<(std::ostream & output, const Nfa & nfa_print){
  for(unsigned int j=0; j< nfa_print.nstates; j++){
    cout << "state n " << j;
    for(unsigned int k=0; k< nfa_print.symbolcount;k++){
      cout << " symbol " << k << " -->";
      for (auto it = nfa_print.delta[j][k].begin(); it != nfa_print.delta[j][k].end(); it++) 
        cout << *it << " "; 
      cout << endl;
    }
  }
  cout << "Accepted states ";
  for (auto it = nfa_print.accepted_states.begin(); it != nfa_print.accepted_states.end(); it++) 
        cout << *it << " "; 
      cout << endl;
  return output;
} 
