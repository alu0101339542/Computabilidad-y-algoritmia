/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Computabilidad y Algoritmia
 *
 * @author Daniel Perez Lozano
 * @email alu0101339542@ull.edu.es
 * @date 7 Nov 2020
 * @brief This program checks whether the pattern given by command line is in any of the sets given by command line
 * @see http://www.cplusplus.com/doc/tutorial/program_structure/
 * @see http://cpp.sh/2dd
 * @compile  g++ -std=c++14 -g -Wall -o pattern_search pattern_search.cc main_pattern_search.cc
*/

#include "pattern_search.h"

int main(int argc, char *argv[]) {
  ifstream input_file; //!< This is the given file from where we will obtain the values
  ofstream output_file; //!< This is the output file where the result of the program will get stored
  string line;
  int result; //!< The return of the search
  
  /*! Check if the files are good */
  input_file.open(argv[2]);
  if(input_file.fail()) {
    cout << "Error opening input file" << argv[2] << endl;
    //cerr << "Error: " << strerror(errno);
    return -1;
  }
  if(input_file.peek() == std::ifstream::traits_type::eof()) {
    cout<< "The input file is empty" << endl;
    return -1;
  }
  output_file.open(argv[3]);
  if(output_file.fail()){
    cout << "Error opening output file" << endl;
    return -1;
  }
  if(argc == 2 && string(argv[1]) == "--help") {
    cout << "The program expects three parameters $> ./pattern_search pattern infile.txt outfile.txt" << endl;
    cout << "input.txt indicates the filename where it will take the sets form" << endl;
    cout << "output.txt is the filename where the words will get stored with its position" << endl;
    return -1;
  }
   if(argc != 4) {
    cout << "Syntax error: " << argv[0] << " was expecting the name of the pattern the input and the output file." << endl;
    cout << "--help for more information " << endl;
    return -1;
  } 
  //! Create a Finite state machine
  FSM fstate(argv[1]);
  //! Get in a string every line of the file, search if the pattern is in it and print the result of the operation in the output file
  while(getline(input_file, line)){
    result = fstate.Search(line);
    fstate.Printresult(result, output_file);
  }
  input_file.close();
  output_file.close();
  return 0;
}
