/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Computabilidad y Algoritmia
 *
 * @author Daniel Perez Lozano
 * @email alu0101339542@ull.edu.es
 * @date 7 Nov 2020
 * @brief This program checks whether the pattern given by command line is in any of the sets given by command line
 * @see http://www.cplusplus.com/doc/tutorial/program_structure/
 * @see http://cpp.sh/2dd
 * @compile  g++ -std=c++14 -g -Wall -o pattern_search pattern_search.cc set_calculator.cc main_pattern_search.cc
*/

#include "pattern_search.h"

//! Constructor, creates the FSM from a pattern
FSM::FSM(string pattern) {
  n_states = pattern.size() +1;
  fstate.resize(n_states);
  for(int i = 0; i < n_states; i ++) {
    fstate[i] = pattern[i];
  }
  istringstream alpha("{a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z}");
  alpha >> alphabet;
}

//! Destuctor
FSM::~FSM() {
  fstate.clear();
  n_states = 0;
}

/** We call the method from the class set to check whether every symbol contained in the chain is 
 * part of the alphabet that the class FSM is using
 */
bool FSM::Checkalpha(string chain) {
  for(unsigned int i = 0; i < chain.size(); i++){
    if(alphabet.Elementinset(chain[i]) == false)
      return false;
  }
  return true;
}

//! This mehod checks if a given substring is equal to the pattern stored in fstate
int FSM::Checkequal(string chain) {
  int q = 0;
  for(int j = 0; j < n_states; j++) {
    if(q == n_states - 1)
      return 1;
    if(chain[j] == fstate[q]) 
      q++;
    else  
      return 0;
  }
  return 0;
}

/** Search checks a whole string and identifies is the given pattern is among it. To do this it creates substrings
 * and calls the method check_equal
 */
int FSM::Search(string chain) {
  if(Checkalpha(chain) == false)
    return -1;
  while(chain.size() >= unsigned(n_states -1)) {
    if(Checkequal(chain) == 1)
      return 1;
    else {
      chain.erase(chain.begin() + 0);
    } 
  }
  return 0;
}

/** This method prints the result of the exercise, to do this it takes the result from the search 
 * function and prints error, no or si depending on what was given
 */
void FSM::Printresult(int result, ofstream & outputfile) {
  switch(result) {
    case -1:
      outputfile << "Error" << endl;
      break;
    case 0:
      outputfile << "No" << endl;
      break;
    case 1:
      outputfile << "Si" << endl;
      break;
    default:
      outputfile << "Error" << endl;
  }
}