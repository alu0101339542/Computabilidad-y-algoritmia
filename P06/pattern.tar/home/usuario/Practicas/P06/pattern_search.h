/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Computabilidad y Algoritmia
 *
 * @author Daniel Perez Lozano
 * @email alu0101339542@ull.edu.es
 * @date 7 Nov 2020
 * @brief This program checks whether the pattern given by command line is
 *  in any of the sets given by command line
 * @see http://www.cplusplus.com/doc/tutorial/program_structure/
 * @see http://cpp.sh/2dd
 * @compile  g++ -std=c++14 -g -Wall -o pattern_search pattern_search.cc main_pattern_search.cc
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "set_calculator.h"

using namespace std;

//! The finite state machine class
class FSM {
  public:
    //FSM(); /**< Default constructor */
    FSM(string pattern); /**< constructor */
    ~FSM(); /**< Destructor */
    bool Checkalpha(string chain); /**< Checks if the symbols of a string are in the alphabet */ 
    int Search(string chain); /**< Searchs for a pattern in a chain */
    int Checkequal(string chain); /**< Checks is a substring is equal to a pattern */
    void Printresult(int result, ofstream & outputfile); /**< Printsthe result of the search in a file */
  private:
    Set alphabet; /**< alphabet of the string */
    int n_states; /**< Number of states of the FSM */
    string fstate; /**< Where the pattern will get stored */
};