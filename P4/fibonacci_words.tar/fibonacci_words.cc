/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Computabilidad y Algoritmia
 *
 * @author Daniel Perez Lozano
 * @email alu0101339542@ull.edu.es
 * @date 23 Oct 2020
 * @brief given a sequence of words indicates whether they are Fibonacci words or not. 
 *        For those that are, the program must indicate their position in the sequence. 
 * @see http://www.cplusplus.com/doc/tutorial/program_structure/
 * @see http://cpp.sh/2dd
 * @compile  g++ -std=c++14 -g -Wall -o fibonacci_words fibonacci_words.cc main_fibonacci_words.cc
*/

#include "fibonacci_words.h"

//! Default constructor, asigns to the first word the character 'a' and 'b' to the second
word::word() {
  word_1 = 'a';
  word_2 = 'b';
}
//! Constructor asigns to each element a character
word::word(char w1, char w2){
  word_1 = w1;
  word_2 = w2;
}
//! Destructor
word::~word() {
}

/** This method generates the fibonacci word of a given position in the sequence. To do this
 * it authomaticly assigns a value when it's the fibonacci word of 1 or 2 and it 
 * applies the formula for values greater than 2
 */
string word::Genfibword(int position) {
  string str; //!< Here is where the accomulated string will be saved
  if (position == 1) { 
    str.push_back(word_1);
    return str;
  }
  if (position == 2) { 
    str.push_back(word_2);
    return str;
  }
  return Genfibword(position - 2) + Genfibword(position - 1);
}

/** This method compares two strings. One is given as an argument and the other
 * one is created by calling every function Genfibword until the resulting string's size is 
 * greater than the given string length. If an equal string is found, it returns the position 
 * of the fibonacci word, if not it returns 0, as there is not a value in the fibonacci 
 * word equal to the given string
 */
int word::CompareStrings(string givenstr) {
  int position = 1;
  string str;
  do {
    if(Genfibword(position) == givenstr) {
      str.clear();
      return position;
    }
    position ++;
  } while(Genfibword(position).length() <= givenstr.length());
  str.clear();
  return 0;
}
