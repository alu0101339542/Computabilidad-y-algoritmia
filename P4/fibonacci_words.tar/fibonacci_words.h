/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Computabilidad y Algoritmia
 *
 * @author Daniel Perez Lozano
 * @email alu0101339542@ull.edu.es
 * @date 23 Oct 2020
 * @brief given a sequence of words indicates whether they are Fibonacci words or not. 
 *        For those that are, the program must indicate their position in the sequence. 
 * @see http://www.cplusplus.com/doc/tutorial/program_structure/
 * @see http://cpp.sh/2dd
 * @compile  g++ -std=c++14 -g -Wall -o fibonacci_words fibonacci_words.cc main_fibonacci_words.cc
*/

#include <iostream>
#include <fstream>
#include <string>
#include <cstring>

using namespace std;
//!  The Fibonacci word class.
class word {
  public:
    word(); /**< Default constructor */
    word(char w1, char w2); /**< Constructor */
    ~word(); /**Destructor */
    string Genfibword(int position); //!< a member function. To generetes the fibonacci word
    int CompareStrings(string givenstr); //!< a member function. To compare one string to a fibonacci word

  private:
    char word_1; /*!< a char that stores the value of the 
                  * first character of the fibonacci word 
                  */
    char word_2; /*!< a char that stores the value of the 
                  * second character of the fibonacci word 
                  */
};