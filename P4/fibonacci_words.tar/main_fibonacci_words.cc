/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Computabilidad y Algoritmia
 *
 * @author Daniel Perez Lozano
 * @email alu0101339542@ull.edu.es
 * @date 23 Oct 2020
 * @brief given a sequence of words indicates whether they are Fibonacci words or not. 
 *        For those that are, the program must indicate their position in the sequence. 
 * @see http://www.cplusplus.com/doc/tutorial/program_structure/
 * @see http://cpp.sh/2dd
 * @compile  g++ -std=c++14 -g -Wall -o fibonacci_words fibonacci_words.cc main_fibonacci_words.cc
*/

#include "fibonacci_words.h"

int main(int argc, char *argv[]) { 
  word fibo;
  string givenstr; //! in this value will be saved the string each time from the file
  ifstream input_file; //!< This is the given file from where we will obtain the values
  ofstream output_file; //!< This is the output file where the result of the program will get stored
  int position; //!< This is the return value of the function that compares the strings

  /** Here it will be checked whether the given values from the command line are the ones expected 
   * and it will take action depending on what they are
   */
  if(argc == 2 && string(argv[1]) == "--help") {
    cout << "The program expects two parameters $> ./fibonacci_words input.txt output.txt" << endl;
    cout << "input.txt indicates the filename where it will take the characters to check"
            "if they are a fibonacci word" << endl;
    cout << "output.txt is the filename where the words will get stored with its position" << endl;
    return -1;
  }
  if(argc != 3) {
    cout << "Syntax error: " << argv[0] << " was expecting the name of the input and the output file." << endl;
    cout<< "--help for more information " << endl;
    return -1;
  } 
  /*! Check if the files are good */
  input_file.open(argv[1]);
  if(input_file.fail()) {
    cout << "Error opening input file" << argv[1] << endl;
    cerr << "Error: " << strerror(errno);
    return -1;
  }
  if(input_file.peek() == std::ifstream::traits_type::eof()) {
    cout<< "The input file is empty" << endl;
    return -1;
  }
  output_file.open(argv[2]);
  if(output_file.fail()){
    cout << "Error opening output file" << endl;
    return -1;
  }
  /** Takes the strings form the file one line at a time, then it calls the method of the class word to compare the strings
   * and stores the result on another file
   */
  while(getline(input_file, givenstr)){
    position = fibo.CompareStrings(givenstr);
    if(position == 0)
      output_file << givenstr << " is not a Fibonacci word" << endl;
      
    if(position != 0) {
      output_file << givenstr.length() <<"- " << givenstr << " is the word number " << position << endl;
    }
  }
  /*! Close the files and finishes the program */
  input_file.close();
  output_file.close();
  return 0;
}

